# ATLAS Pilot Dataset — Gurgel BR-800

Pilot dataset for semantic-model validation. It is deliberately selective, not an exhaustive catalogue.

## Model findings
- Corporate 'end' cannot be one scalar field; insolvency, bankruptcy, operations end and legal/brand continuity are separate events.
- The same organization and brand must remain distinct entities.
- BR-800 production end is well represented separately from later corporate failure.

## Structural validation
PASSED
