# ATLAS — A5 Chapter I: 1885–1918

## Chapter thesis
This chapter is not "a list of the oldest cars".

It follows the transformation:

**experimental self-propelled vehicles → repeatable products → manufacturers and brands → industrial production → standardization → mass production and competition.**

## Batch 1 — Foundation spine
Already inserted into the canonical working snapshot:
- Benz Patent Motor Car
- Daimler Motorized Carriage
- Peugeot Type 1 / Type 2 / Type 3
- Renault Frères foundation
- FIAT 3½ HP / FIAT foundation
- Royce 10 H.P. → Rolls-Royce 10 H.P.
- Ford Quadricycle
- Ford Model A
- Oldsmobile Curved Dash
- Cadillac Runabout
- Ford Model T
- moving assembly line

## Research batches

### B2 — France as early industrial ecosystem
Panhard & Levassor, De Dion-Bouton, deeper Peugeot, Renault Type A.

### B3 — German engineering lineages
Benz Velo, Daimler commercial vehicles, Mercedes naming and Mercedes 35 hp.

### B4 — Italy and United Kingdom
FIAT scaling, Lancia formation, Rolls-Royce and Silver Ghost.

### B5 — United States: from experimentation to volume
Oldsmobile, Cadillac standardization, Ford facilities and production system.

### B6 — Motorsport becomes an institution
Paris–Rouen, Gordon Bennett, early Grand Prix and the link between competition and product development.

### B7 — Component/supplier network
Only suppliers that materially explain vehicle development:
engines, coachbuilders, tires, ignition/electrical systems, manufacturing technologies.

### B8 — 1914–1918 transition
Track how war altered factories, production priorities and technologies.
Do not turn the Atlas into a military-vehicle catalogue.

## Geographic principle
1885–1918 is historically concentrated in Europe and the United States.
Do not create token entities for every continent merely to make the chapter visually global.
Represent international diffusion when meaningful sources/events exist.

## Exit gate
Chapter I is complete enough when a user can navigate:
invention → inventor → vehicle → company → successor → factory/technology → competition/market event → mass production,
with provenance at every load-bearing step.

Completeness of every surviving pioneer manufacturer is not required for v1.
