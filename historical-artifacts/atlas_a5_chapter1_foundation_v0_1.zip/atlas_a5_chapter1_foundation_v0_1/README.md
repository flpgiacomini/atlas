# ATLAS A5 Chapter I Foundation v0.1

First production-research batch for Chapter I (1885–1918).

Contains:
- canonical working SQLite snapshot;
- derived historical timeline;
- Batch 1 validation;
- research queue for remaining chapter batches;
- chapter plan and narrative spine report.
