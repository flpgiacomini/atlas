# A1 Tool Decision

## Provisional workspace winner
**Heurist**

It is the best current balance between historical-research workflow, heterogeneous relationships,
temporal/spatial data, maps/timelines/networks, import/export and avoiding custom software.

## Semantic benchmark
**Wikibase**

Wikibase remains the closest semantic analogue to the Atlas Statement model and the first migration target
if Heurist loses provenance or round-trip fidelity.

## Canonical authority
Neither Heurist nor Wikibase.
For A3/A4 the canonical portable reference is Atlas SQLite v1 + exports.

## Supporting tools
- Zotero: source capture/library
- OpenRefine: cleaning and Entity Resolution
- Heurist: provisional curation workspace
- SQLite: canonical snapshot
- Datasette: optional immediate browser/API
