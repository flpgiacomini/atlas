# ATLAS Canonical Data Model v1.0

Canonical v1 package generated from the validated five-case pilot.

Validation passed: **True**
Errors: **0**
Warnings: **0**

Counts:
```json
{
  "entity": 86,
  "entity_name": 14,
  "external_identifier": 2,
  "predicate": 54,
  "statement": 131,
  "source": 24,
  "claim": 203,
  "evidence": 203,
  "claim_evidence": 203,
  "legacy_identifier": 648
}
```

The warnings are registry-compatibility/reconciliation signals, not integrity failures.

Key files:
- `atlas_canonical_pilot_v1_0.sqlite`
- `sql/atlas_v1_schema.sql`
- `schemas/`
- `PREDICATE_REGISTRY_v1.0.json`
- `MIGRATION_MAP.csv`
- `atlas_snapshot_v1.jsonl`
- `VALIDATION_RESULT.json`
- `scripts/validate_atlas_db.py`
- `docs/`
