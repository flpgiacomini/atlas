#!/usr/bin/env sh
cd "$(dirname "$0")/site"
python -m http.server 8000
