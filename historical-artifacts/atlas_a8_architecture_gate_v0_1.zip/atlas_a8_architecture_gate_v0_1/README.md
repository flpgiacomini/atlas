# ATLAS A8 Architecture Gate v0.1

A8 result: **PASS**

This package proves that the A7 Content MVP can be published without a production backend.

## Static POC
`site/`

Run locally:

Windows:
`serve.bat`

Linux/macOS:
`chmod +x serve.sh && ./serve.sh`

Then open `http://127.0.0.1:8000`.

## Proof counts
- 334 generated Entity pages
- 326 global entity-to-entity graph edges
- 102 dated Events
- 14 prototype map points
- no FastAPI runtime required

## Important
The POC generator is intentionally simple.
The durable A9 web implementation should use **Astro + Pagefind** while preserving this static data contract.
