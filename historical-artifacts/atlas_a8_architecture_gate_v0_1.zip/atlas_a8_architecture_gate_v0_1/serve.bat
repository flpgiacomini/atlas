@echo off
cd /d "%~dp0site"
python -m http.server 8000
