
const esc = v => String(v ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
async function setupSearch(){
  const input=document.querySelector("#global-search");
  const box=document.querySelector("#global-results");
  if(!input||!box)return;
  const idx=await fetch(relativeRoot()+"data/search-index.json").then(r=>r.json());
  const norm=s=>(s||"").toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu,"");
  input.addEventListener("input",()=>{
    const q=norm(input.value.trim());
    if(q.length<2){box.classList.add("hidden");box.innerHTML="";return;}
    const rows=idx.map(x=>{
      const name=norm(x.name), aliases=norm((x.aliases||[]).join(" "));
      let score=name===q?0:name.startsWith(q)?1:name.includes(q)?2:aliases.includes(q)?3:99;
      return [score,x];
    }).filter(x=>x[0]<99).sort((a,b)=>a[0]-b[0]||a[1].name.localeCompare(b[1].name)).slice(0,30);
    box.innerHTML=rows.length?rows.map(([_,x])=>`<a href="${relativeRoot()}${x.url}"><span>${esc(x.name)}</span><small>${esc(x.type)}</small></a>`).join(""):`<a><span>Sem resultados</span></a>`;
    box.classList.remove("hidden");
  });
  document.addEventListener("click",e=>{if(!e.target.closest(".static-search"))box.classList.add("hidden")});
}
function relativeRoot(){
  const marker="/entity/";
  return location.pathname.includes(marker)?"../":"";
}
function buildGraph(){
  if(!window.ATLAS_ENTITY_GRAPH || !window.cytoscape)return;
  const d=window.ATLAS_ENTITY_GRAPH;
  const cy=cytoscape({
    container:document.querySelector("#graph"),
    elements:[
      ...d.nodes.map(n=>({data:{id:n.id,label:n.name,type:n.type}})),
      ...d.edges.map(e=>({data:{id:e.id,source:e.s,target:e.o,label:e.p}}))
    ],
    style:[
      {selector:"node",style:{"background-color":"#29313a","label":"data(label)","color":"#dfe5eb","font-size":"9px","text-wrap":"wrap","text-max-width":"105px","text-valign":"bottom","text-margin-y":"7px","width":"32px","height":"32px"}},
      {selector:`node[id = "${d.root}"]`,style:{"background-color":"#d7ff68","width":"46px","height":"46px"}},
      {selector:"node[type = 'event']",style:{"shape":"diamond","background-color":"#42566b"}},
      {selector:"node[type = 'person']",style:{"background-color":"#55513c"}},
      {selector:"node[type = 'entry']",style:{"shape":"hexagon","background-color":"#4f3f58"}},
      {selector:"edge",style:{"width":1,"line-color":"#39424c","target-arrow-color":"#596572","target-arrow-shape":"triangle","curve-style":"bezier","label":"data(label)","font-size":"7px","color":"#74808c","text-background-color":"#0e1115","text-background-opacity":.85}}
    ],
    layout:{name:"cose",animate:false,fit:true,padding:30,nodeRepulsion:8000,idealEdgeLength:90}
  });
  cy.on("tap","node",evt=>{
    const id=evt.target.id();
    if(id!==d.root) location.href=`${id}.html`;
  });
}
function buildTimeline(){
  if(!window.ATLAS_ENTITY_TIMELINE || !window.vis)return;
  const rows=window.ATLAS_ENTITY_TIMELINE, el=document.querySelector("#timeline");
  if(!el||!rows.length)return;
  const items=new vis.DataSet(rows.map((r,i)=>{
    let start=r.date;if(/^\d{4}$/.test(start))start+="-01-01";else if(/^\d{4}-\d{2}$/.test(start))start+="-01";
    return {id:i,content:esc(r.name),start,title:`${r.date} · ${r.name}`};
  }));
  new vis.Timeline(el,items,{stack:true,orientation:"top",margin:{item:10,axis:10}});
}
document.addEventListener("DOMContentLoaded",()=>{setupSearch();buildGraph();buildTimeline();});
