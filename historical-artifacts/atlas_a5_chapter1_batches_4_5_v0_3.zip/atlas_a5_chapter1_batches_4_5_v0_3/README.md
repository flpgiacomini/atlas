# ATLAS A5 Chapter I — Batches B4 + B5 v0.3

Adds:
- Lancia foundation and 12 HP
- Rolls-Royce 40/50 H.P. / original Silver Ghost chassis
- Oldsmobile production-scale milestone
- Cadillac interchangeable-parts / Dewar Trophy
- Ford Model N context

Updated canonical SQLite snapshot, timeline, validation and research queue included.
