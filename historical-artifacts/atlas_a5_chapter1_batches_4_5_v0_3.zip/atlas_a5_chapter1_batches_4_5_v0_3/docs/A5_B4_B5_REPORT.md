# ATLAS — A5 Batches B4 + B5 Report

## Result
**PASS**

Added:
- Entities: 19
- Statements: 27
- Sources: 10
- Claims/Evidence: 30 / 30
- New root Entity types: 0
- New Predicates: 0

Canonical totals:
{
  "entity": 243,
  "statement": 320,
  "source": 89,
  "claim": 419,
  "evidence": 419,
  "predicate": 54
}

## B4 — Italy / United Kingdom
Lancia is represented through:
founders → Lancia & C. → foundation Event → Lancia 12 HP.

Rolls-Royce now distinguishes:
40/50 H.P. Vehicle family → physical chassis 60551 → 'Silver Ghost' naming Event → reliability-trial Event.

That separation matters because 'Silver Ghost' began as the name of a specific chassis before becoming the model's common designation.

## B5 — United States
Oldsmobile Curved Dash is connected to a production-scale Event rather than forcing a bespoke 'mass_produced' predicate.

Cadillac Model K connects to:
interchangeable-parts Technology → 1908 Dewar Trophy Event.

Ford Model N adds the important pre-Model-T mass-market step.

## Modeling conclusion
Industrial milestones are best represented as:
Vehicle/Organization/Technology + Event,
with numeric/summary production facts in metadata unless repeated analytical needs justify dedicated Predicates.

No Data Model revision was required.
