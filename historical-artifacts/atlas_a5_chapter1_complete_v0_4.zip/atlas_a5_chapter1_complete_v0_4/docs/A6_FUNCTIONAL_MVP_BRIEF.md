# ATLAS — A6 Functional MVP Brief

## Goal
Build the smallest exploration experience that proves the Atlas feels like an atlas rather than a database admin panel.

## Canonical source
Read from/export from Atlas canonical SQLite v1.
Do not redesign the data model for frontend convenience.

## Required flows

### Flow 1 — Vehicle exploration
Porsche 917
→ chassis 917-023
→ 1970 Le Mans Entry
→ Hans Herrmann / Richard Attwood
→ event
→ Circuit de la Sarthe

### Flow 2 — Genealogy
Porsche 911
→ generations
→ predecessor/successor traversal
→ historic 901 naming conflict
→ evidence

### Flow 3 — Industry history
Benz Patent Motor Car
→ Carl Benz
→ Benz Velo
→ Benz & Cie.
→ wartime aeroengine shift

### Flow 4 — Technology
Ford Model T
→ Highland Park
→ moving assembly line
→ industrial timeline

### Flow 5 — Motorsport origin
Paris–Rouen 1894
→ Panhard/Peugeot
→ Vanderbilt Cup
→ 1906 Grand Prix
→ Renault / Ferenc Szisz

## Required UI surfaces
1. Global search
2. Entity page
3. Relationship section
4. Timeline view
5. Map view
6. Graph/genealogy view
7. Evidence/source drawer
8. Compare view — minimal, only common facts

## Not required in A6
- user accounts
- editing/curation UI
- mobile app
- 3D
- AI chat
- automatic ingestion
- design system perfection
- graph database
- SSR complexity unless actually useful

## Technology gate
Before selecting a custom stack, test whether Datasette + lightweight static/custom views can satisfy the first flows.

A6 must prefer reuse over framework construction.
