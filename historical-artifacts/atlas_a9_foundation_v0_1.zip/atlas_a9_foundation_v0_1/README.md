# ATLAS A9 Foundation v0.1

This package starts the final product implementation phase.

It contains:
- `atlas-web/` — static Astro project scaffold;
- canonical A7 SQLite snapshot;
- build-time exporter;
- Entity route/components;
- Pagefind build contract;
- A9 pipeline/status documentation.

A9 is not complete yet. This package establishes the durable web/build foundation selected by A8.
