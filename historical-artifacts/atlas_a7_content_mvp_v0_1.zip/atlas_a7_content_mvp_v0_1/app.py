from __future__ import annotations

from collections import deque
from pathlib import Path
import json
import sqlite3
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

BASE = Path(__file__).resolve().parent
DB_PATH = BASE / "data" / "atlas.sqlite"
GEO_PATH = BASE / "data" / "geo_points.json"

app = FastAPI(
    title="ATLAS Functional MVP",
    version="0.1.0",
    description="Disposable read-only exploration shell over the canonical Atlas SQLite snapshot.",
)
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")


def connect():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA query_only = ON")
    return db


def parse_json(value, default):
    if not value:
        return default
    try:
        return json.loads(value)
    except Exception:
        return default


def object_value(row):
    if row["object_type"] == "entity":
        return row["object_name"]
    if row["object_type"] == "date":
        return row["object_date"]
    if row["object_type"] in ("number", "quantity"):
        if row["object_number"] is None:
            return None
        unit = row["object_unit"] or ""
        return f'{row["object_number"]:g}{(" " + unit) if unit else ""}'
    if row["object_type"] == "boolean":
        return bool(row["object_boolean"])
    return row["object_text"]


@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")


@app.get("/api/stats")
def stats():
    with connect() as db:
        counts = {
            name: db.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0]
            for name in ("entity", "statement", "source", "claim", "evidence", "predicate")
        }
        types = [
            dict(r)
            for r in db.execute(
                "SELECT entity_type, COUNT(*) AS count FROM entity GROUP BY entity_type ORDER BY count DESC"
            )
        ]
    return {"counts": counts, "types": types}


@app.get("/api/featured")
def featured():
    names = [
        "Benz Patent Motor Car",
        "Ford Model T",
        "Citroën Traction Avant",
        "Volkswagen Beetle / Type 1",
        "Classic Mini",
        "Lamborghini Miura",
        "Volkswagen Golf — First Generation",
        "Porsche 917",
        "Gurgel BR-800",
        "Toyota Prius — First Generation",
        "Tesla Roadster — First Generation",
        "BYD F3DM",
    ]
    with connect() as db:
        result = []
        for name in names:
            row = db.execute(
                "SELECT id, entity_type, canonical_name FROM entity WHERE canonical_name = ?",
                (name,),
            ).fetchone()
            if row:
                result.append(dict(row))
    return result


@app.get("/api/search")
def search(q: str = Query("", max_length=120), entity_type: Optional[str] = None, limit: int = 30):
    q = q.strip()
    if not q:
        return []
    limit = max(1, min(limit, 80))
    params = [f"%{q}%", f"%{q}%"]
    type_clause = ""
    if entity_type:
        type_clause = " AND e.entity_type = ? "
        params.append(entity_type)
    params.append(limit)
    sql = f"""
    SELECT DISTINCT e.id, e.entity_type, e.canonical_name, e.description
    FROM entity e
    LEFT JOIN entity_name n ON n.entity_id = e.id
    WHERE (e.canonical_name LIKE ? COLLATE NOCASE OR n.value LIKE ? COLLATE NOCASE)
      {type_clause}
    ORDER BY
      CASE WHEN lower(e.canonical_name) = lower(?) THEN 0
           WHEN lower(e.canonical_name) LIKE lower(?) THEN 1
           ELSE 2 END,
      e.canonical_name
    LIMIT ?
    """
    # exact and prefix ranking
    params = params[:-1] + [q, q + "%", params[-1]]
    with connect() as db:
        return [dict(r) for r in db.execute(sql, params)]


def statement_rows(db, entity_id, direction):
    if direction == "out":
        sql = """
        SELECT s.*, p.name predicate, oe.canonical_name object_name,
               (SELECT COUNT(*) FROM claim c WHERE c.statement_id=s.id) claim_count
        FROM statement s
        JOIN predicate p ON p.id=s.predicate_id
        LEFT JOIN entity oe ON oe.id=s.object_entity_id
        WHERE s.subject_entity_id=?
        ORDER BY p.name, COALESCE(oe.canonical_name,s.object_date,s.object_text)
        """
    else:
        sql = """
        SELECT s.*, p.name predicate, se.canonical_name subject_name,
               (SELECT COUNT(*) FROM claim c WHERE c.statement_id=s.id) claim_count
        FROM statement s
        JOIN predicate p ON p.id=s.predicate_id
        JOIN entity se ON se.id=s.subject_entity_id
        WHERE s.object_type='entity' AND s.object_entity_id=?
        ORDER BY p.name, se.canonical_name
        """
    return list(db.execute(sql, (entity_id,)))


@app.get("/api/entities/{entity_id}")
def entity_detail(entity_id: str):
    with connect() as db:
        entity = db.execute("SELECT * FROM entity WHERE id=?", (entity_id,)).fetchone()
        if not entity:
            raise HTTPException(404, "Entity not found")

        names = [dict(r) for r in db.execute(
            "SELECT value,name_type,language,valid_from,valid_until FROM entity_name WHERE entity_id=? ORDER BY name_type,value",
            (entity_id,),
        )]
        ext = [dict(r) for r in db.execute(
            "SELECT scheme,value,url FROM external_identifier WHERE entity_id=? ORDER BY scheme,value",
            (entity_id,),
        )]

        outgoing = []
        facts = []
        for r in statement_rows(db, entity_id, "out"):
            base = {
                "statement_id": r["id"],
                "predicate": r["predicate"],
                "object_type": r["object_type"],
                "confidence": r["confidence"],
                "resolution_status": r["resolution_status"],
                "valid_from": r["valid_from"],
                "valid_until": r["valid_until"],
                "qualifiers": parse_json(r["qualifiers_json"], {}),
                "claim_count": r["claim_count"],
            }
            if r["object_type"] == "entity":
                base.update({"object_id": r["object_entity_id"], "object_name": r["object_name"]})
                outgoing.append(base)
            else:
                base["value"] = object_value(r)
                facts.append(base)

        incoming = []
        for r in statement_rows(db, entity_id, "in"):
            incoming.append({
                "statement_id": r["id"],
                "predicate": r["predicate"],
                "subject_id": r["subject_entity_id"],
                "subject_name": r["subject_name"],
                "confidence": r["confidence"],
                "resolution_status": r["resolution_status"],
                "valid_from": r["valid_from"],
                "valid_until": r["valid_until"],
                "qualifiers": parse_json(r["qualifiers_json"], {}),
                "claim_count": r["claim_count"],
            })

        # Events that directly involve this entity.
        events = [
            dict(r)
            for r in db.execute(
                """
                SELECT DISTINCT ev.id, ev.canonical_name,
                       d.object_date AS date, d.object_date_precision AS precision
                FROM statement inv
                JOIN predicate ip ON ip.id=inv.predicate_id AND ip.name='involved'
                JOIN entity ev ON ev.id=inv.subject_entity_id AND ev.entity_type='event'
                LEFT JOIN statement d ON d.subject_entity_id=ev.id
                LEFT JOIN predicate dp ON dp.id=d.predicate_id AND dp.name='occurred_on'
                WHERE inv.object_type='entity' AND inv.object_entity_id=?
                ORDER BY d.object_date, ev.canonical_name
                """,
                (entity_id,),
            )
        ]

        return {
            "entity": {
                **dict(entity),
                "metadata": parse_json(entity["metadata_json"], {}),
            },
            "names": names,
            "external_ids": ext,
            "outgoing": outgoing,
            "incoming": incoming,
            "facts": facts,
            "events": events,
        }


@app.get("/api/statements/{statement_id}/evidence")
def statement_evidence(statement_id: str):
    with connect() as db:
        statement = db.execute(
            """
            SELECT s.*, p.name predicate, se.canonical_name subject_name,
                   oe.canonical_name object_name
            FROM statement s
            JOIN predicate p ON p.id=s.predicate_id
            JOIN entity se ON se.id=s.subject_entity_id
            LEFT JOIN entity oe ON oe.id=s.object_entity_id
            WHERE s.id=?
            """,
            (statement_id,),
        ).fetchone()
        if not statement:
            raise HTTPException(404, "Statement not found")

        rows = db.execute(
            """
            SELECT c.id claim_id,c.stance,c.support_strength,c.note claim_note,
                   e.id evidence_id,e.evidence_type,e.locator_json,e.excerpt,e.notes evidence_notes,
                   src.id source_id,src.title,src.publisher,src.published_at,src.url,src.source_type,src.source_tier
            FROM claim c
            JOIN claim_evidence ce ON ce.claim_id=c.id
            JOIN evidence e ON e.id=ce.evidence_id
            JOIN source src ON src.id=e.source_id
            WHERE c.statement_id=?
            ORDER BY src.publisher,src.title
            """,
            (statement_id,),
        )
        return {
            "statement": {
                "id": statement["id"],
                "subject_name": statement["subject_name"],
                "predicate": statement["predicate"],
                "object_type": statement["object_type"],
                "object_value": object_value(statement),
                "confidence": statement["confidence"],
                "resolution_status": statement["resolution_status"],
                "qualifiers": parse_json(statement["qualifiers_json"], {}),
            },
            "evidence": [
                {
                    **dict(r),
                    "locator": parse_json(r["locator_json"], {}),
                }
                for r in rows
            ],
        }


@app.get("/api/graph/{entity_id}")
def graph(entity_id: str, depth: int = 2, limit: int = 90):
    depth = max(1, min(depth, 3))
    limit = max(10, min(limit, 180))
    with connect() as db:
        root = db.execute("SELECT id,entity_type,canonical_name FROM entity WHERE id=?", (entity_id,)).fetchone()
        if not root:
            raise HTTPException(404, "Entity not found")

        seen = {entity_id: 0}
        q = deque([entity_id])
        nodes = {}
        edges = {}
        while q and len(nodes) < limit:
            current = q.popleft()
            d = seen[current]
            row = db.execute("SELECT id,entity_type,canonical_name FROM entity WHERE id=?", (current,)).fetchone()
            if row:
                nodes[current] = dict(row)
            if d >= depth:
                continue

            rels = db.execute(
                """
                SELECT s.id,p.name predicate,s.subject_entity_id,s.object_entity_id,
                       a.entity_type subject_type,a.canonical_name subject_name,
                       b.entity_type object_type,b.canonical_name object_name,
                       s.confidence,s.resolution_status
                FROM statement s
                JOIN predicate p ON p.id=s.predicate_id
                JOIN entity a ON a.id=s.subject_entity_id
                JOIN entity b ON b.id=s.object_entity_id
                WHERE s.object_type='entity'
                  AND (s.subject_entity_id=? OR s.object_entity_id=?)
                """,
                (current,current),
            )
            for r in rels:
                edges[r["id"]] = dict(r)
                for nid, ntype, nname in (
                    (r["subject_entity_id"],r["subject_type"],r["subject_name"]),
                    (r["object_entity_id"],r["object_type"],r["object_name"]),
                ):
                    if nid not in nodes:
                        nodes[nid] = {"id":nid,"entity_type":ntype,"canonical_name":nname}
                    if nid not in seen and len(nodes) < limit:
                        seen[nid] = d + 1
                        q.append(nid)

        return {"root": entity_id, "nodes": list(nodes.values()), "edges": list(edges.values())}


@app.get("/api/timeline")
def timeline(entity_id: Optional[str] = None, start_year: int = 1880, end_year: int = 2035, limit: int = 200):
    limit = max(10, min(limit, 500))
    with connect() as db:
        if entity_id:
            sql = """
            SELECT DISTINCT ev.id,ev.canonical_name,
                   d.object_date date,d.object_date_precision precision,
                   inv.qualifiers_json
            FROM entity ev
            JOIN statement inv ON inv.subject_entity_id=ev.id
            JOIN predicate ip ON ip.id=inv.predicate_id AND ip.name='involved'
            JOIN statement d ON d.subject_entity_id=ev.id
            JOIN predicate dp ON dp.id=d.predicate_id AND dp.name='occurred_on'
            WHERE ev.entity_type='event'
              AND inv.object_type='entity'
              AND inv.object_entity_id=?
              AND CAST(substr(d.object_date,1,4) AS INTEGER) BETWEEN ? AND ?
            ORDER BY d.object_date
            LIMIT ?
            """
            rows = db.execute(sql,(entity_id,start_year,end_year,limit))
        else:
            sql = """
            SELECT DISTINCT ev.id,ev.canonical_name,
                   d.object_date date,d.object_date_precision precision,
                   '{}' qualifiers_json
            FROM entity ev
            JOIN statement d ON d.subject_entity_id=ev.id
            JOIN predicate dp ON dp.id=d.predicate_id AND dp.name='occurred_on'
            WHERE ev.entity_type='event'
              AND CAST(substr(d.object_date,1,4) AS INTEGER) BETWEEN ? AND ?
            ORDER BY d.object_date
            LIMIT ?
            """
            rows = db.execute(sql,(start_year,end_year,limit))
        return [
            {
                **dict(r),
                "qualifiers": parse_json(r["qualifiers_json"], {}),
            }
            for r in rows
        ]


@app.get("/api/map")
def map_points():
    points = json.loads(GEO_PATH.read_text(encoding="utf-8"))
    with connect() as db:
        for p in points:
            row = db.execute(
                "SELECT id,entity_type FROM entity WHERE canonical_name=?",
                (p["entity_name"],),
            ).fetchone()
            if row:
                p["entity_id"] = row["id"]
                p["entity_type"] = row["entity_type"]
    return points


@app.get("/api/compare")
def compare(ids: str):
    entity_ids = [x.strip() for x in ids.split(",") if x.strip()][:4]
    if len(entity_ids) < 2:
        raise HTTPException(400, "Provide at least two entity IDs")
    result = []
    with connect() as db:
        for entity_id in entity_ids:
            e = db.execute("SELECT * FROM entity WHERE id=?", (entity_id,)).fetchone()
            if not e:
                continue
            facts = []
            for r in statement_rows(db, entity_id, "out"):
                facts.append({
                    "predicate": r["predicate"],
                    "object_type": r["object_type"],
                    "value": object_value(r),
                    "object_id": r["object_entity_id"],
                    "confidence": r["confidence"],
                })
            result.append({
                "id":e["id"],
                "name":e["canonical_name"],
                "type":e["entity_type"],
                "metadata":parse_json(e["metadata_json"],{}),
                "facts":facts,
            })
    return result


@app.get("/api/path")
def path_between(from_id: str, to_id: str, max_depth: int = 5):
    max_depth=max(1,min(max_depth,7))
    if from_id==to_id:
        return {"nodes":[from_id],"edges":[]}
    with connect() as db:
        parents={from_id:(None,None)}
        q=deque([(from_id,0)])
        found=False
        while q and not found:
            node,d=q.popleft()
            if d>=max_depth:
                continue
            rows=db.execute("""
                SELECT s.id,p.name,s.subject_entity_id,s.object_entity_id
                FROM statement s JOIN predicate p ON p.id=s.predicate_id
                WHERE s.object_type='entity' AND (s.subject_entity_id=? OR s.object_entity_id=?)
            """,(node,node))
            for r in rows:
                nxt=r["object_entity_id"] if r["subject_entity_id"]==node else r["subject_entity_id"]
                if nxt in parents:
                    continue
                parents[nxt]=(node,dict(r))
                if nxt==to_id:
                    found=True
                    break
                parents[nxt]=(node,dict(r))
                q.append((nxt,d+1))
        if to_id not in parents:
            return {"nodes":[],"edges":[]}
        nodes=[]
        edges=[]
        cur=to_id
        while cur is not None:
            nodes.append(cur)
            parent,edge=parents[cur]
            if edge:
                edges.append(edge)
            cur=parent
        nodes.reverse(); edges.reverse()
        labels={}
        for nid in nodes:
            r=db.execute("SELECT canonical_name,entity_type FROM entity WHERE id=?",(nid,)).fetchone()
            labels[nid]=dict(r) if r else {"canonical_name":nid,"entity_type":"unknown"}
        return {"nodes":[{"id":n,**labels[n]} for n in nodes],"edges":edges}
