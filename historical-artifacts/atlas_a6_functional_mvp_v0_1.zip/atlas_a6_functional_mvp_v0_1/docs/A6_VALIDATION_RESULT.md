# A6 v0.1 — Validation Result

## Technical result
**PASS**

The packaged smoke test runs against the actual A5 canonical SQLite snapshot.

Verified:
- global search;
- Entity detail API;
- incoming/outgoing relationships;
- graph expansion;
- entity-related timeline;
- Statement → Claim/Evidence/Source retrieval;
- Porsche 901→911 conflicting dates remain simultaneously visible and `disputed`;
- two-entity comparison;
- shortest-path traversal;
- prototype map data;
- root HTML delivery;
- Python compilation;
- JavaScript syntax.

## Recorded smoke-test highlights
- Canonical snapshot: 267 Entities / 360 Statements / 99 Sources.
- `Porsche 917` search returns matching family/variants/instances/events.
- Porsche 917 two-hop graph: 20 nodes / 25 edges.
- Porsche 917 Entity page: 3 outgoing + 9 incoming relations and 4 related Events.
- Evidence lookup on a 917 Statement returns multiple source records.
- Porsche 901→911 rename retains:
  - 1964-10-22
  - 1964-11-22
  both as disputed facts.
- Comparison API successfully returns Ford Model T and Benz Patent Motor Car.
- Shortest-path API resolves the 1970 Le Mans winning Entry directly to Richard Attwood.
- Prototype map exposes 10 non-canonical derived points.

## Visual acceptance status
**PENDING MANUAL RUN**

An automated Chromium/Playwright visual check was attempted, but the execution environment blocks browser access to the local loopback server (`ERR_BLOCKED_BY_ADMINISTRATOR`).

This is an environment restriction, not an application/API failure.

Therefore A6 should not be declared fully closed until the package is opened once in a normal browser and the following are visually checked:
1. search interaction;
2. Entity page readability;
3. Evidence drawer;
4. Cytoscape graph;
5. vis-timeline;
6. Leaflet map;
7. basic comparison layout.

## Phase status
**A6 implementation: complete.**
**A6 technical gate: passed.**
**A6 visual/product gate: pending one manual hands-on run.**
