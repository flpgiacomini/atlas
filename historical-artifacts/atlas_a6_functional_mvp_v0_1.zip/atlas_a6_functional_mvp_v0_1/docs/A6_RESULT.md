# A6 v0.1 — Functional MVP Result

## What this prototype tests
A6 v0.1 tests whether the canonical Atlas model can be consumed directly by a lightweight exploration UI,
without an ORM, graph database, duplicated timeline store or custom map database.

## Current architecture
Canonical SQLite → tiny read-only API → plain browser UI.

## Important result
All required information surfaces are derived from the canonical model:
- entity overview;
- relations;
- facts;
- provenance;
- timeline;
- graph;
- comparison.

The map is the only deliberately incomplete semantic surface because canonical geographic coordinates have not yet
been curated. Prototype coordinates live outside the canonical database.

## Decision gate after hands-on use
If the shell is conceptually pleasant:
- preserve these API/view contracts;
- improve geography;
- decide whether Datasette can replace part of the temporary API;
- only then evaluate a durable frontend stack.

If the shell feels like a database browser:
- improve information architecture before adding frameworks.

Do not interpret frontend polish problems as evidence that the data model needs to change.
