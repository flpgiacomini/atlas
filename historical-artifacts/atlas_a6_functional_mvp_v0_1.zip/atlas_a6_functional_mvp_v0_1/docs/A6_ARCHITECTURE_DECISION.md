# A6 — Architecture Decision v0.1

## Decision
Build the first functional exploration shell as a **replaceable read-only adapter** over canonical SQLite.

### Canonical
`data/atlas.sqlite`

### Temporary backend
FastAPI + sqlite3.

Why FastAPI here:
- already available in the working environment;
- trivial read-only JSON endpoints;
- no ORM;
- no schema migration layer;
- no authentication;
- disposable without changing canonical data.

This is **not** a decision that the final Atlas backend will be FastAPI.

## Datasette role
Datasette remains a valid zero/low-code administrative browser:
- SQLite exploration;
- JSON API;
- facets/search/plugins;
- custom templates.

The A6 package contains a Datasette metadata profile, but Datasette was not installed in the execution environment,
so the working prototype uses the temporary FastAPI adapter.

## Frontend
No React/Vue/Svelte/Next.js in A6.

Plain HTML/CSS/JS:
- Cytoscape.js — graph
- vis-timeline — timeline
- Leaflet — map
- OpenStreetMap tiles — prototype basemap

The purpose is to test the product experience, not frontend framework ergonomics.

## Backend endpoints
- `/api/search`
- `/api/entities/{id}`
- `/api/statements/{id}/evidence`
- `/api/graph/{id}`
- `/api/timeline`
- `/api/map`
- `/api/compare`
- `/api/path`
- `/api/stats`

## Read-only guarantee
SQLite connections use `PRAGMA query_only = ON`.
No write endpoint exists.

## Map warning
A5 did not yet contain canonical coordinates.
`geo_points.json` contains prototype-only approximate coordinates solely to test the map surface.
They are explicitly non-canonical and must not flow back into Atlas data without reconciliation/source work.
