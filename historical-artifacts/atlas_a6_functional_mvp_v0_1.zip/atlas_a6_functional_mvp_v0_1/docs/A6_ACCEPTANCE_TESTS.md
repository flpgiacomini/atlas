# A6 Functional Acceptance Tests

## Flow 1 — Vehicle → Motorsport
1. Search Porsche 917.
2. Open relationship graph.
3. Navigate toward Porsche 917-023 / Entry.
4. Open Evidence for a Statement.
5. Confirm sources are shown without exposing Claim/Evidence complexity on the main page.

PASS if exploration is possible without SQL knowledge.

## Flow 2 — Porsche 911 genealogy
1. Search Porsche 911.
2. Follow generation relationships.
3. Find Porsche 901 renamed Porsche 911 Event.
4. Open disputed date Statements.
5. Verify provenance preserves both values.

## Flow 3 — Industrial history
1. Search Benz Patent Motor Car.
2. Navigate to Carl Benz / related events.
3. Search Benz & Cie.
4. Find 1914 aeroengine production shift in timeline/network.

## Flow 4 — Technology
1. Search Ford Model T.
2. Navigate related manufacturing/facility/technology records.
3. Open timeline.

## Flow 5 — Early Motorsport
1. Search Paris–Rouen reliability trial 1894.
2. Navigate Panhard & Levassor / Peugeot / De Dion-Bouton.
3. Search 1906 Grand Prix de l'A.C.F.
4. Navigate its Entry and driver Ferenc Szisz.

## Surface gates
- Search: required
- Entity page: required
- Relations: required
- Evidence drawer: required
- Timeline: required
- Graph: required
- Map: proof-of-surface only in v0.1
- Compare: minimal structural comparison

## A6 v0.1 success rule
The prototype does not need to look final.
It succeeds if the exploration loop feels meaningfully better than browsing raw tables.
