# ATLAS A6 Functional MVP v0.1

A disposable, read-only exploration prototype over the canonical A5 SQLite snapshot.

## Run

### Windows
1. Open a terminal in this folder.
2. If needed: `pip install -r requirements.txt`
3. Run `run.bat`
4. Open `http://127.0.0.1:8000`

### Linux/macOS
1. `pip install -r requirements.txt`
2. `chmod +x run.sh && ./run.sh`
3. Open `http://127.0.0.1:8000`

FastAPI also exposes API documentation at `/docs`.

## What works
- global search
- entity page
- incoming/outgoing relationships
- scalar facts
- source/evidence drawer
- directly-related event timeline
- two-hop Cytoscape graph
- prototype Leaflet map
- basic comparison
- shortest-path API

## What is deliberately absent
- editing
- accounts
- custom ingestion
- AI
- graph database
- frontend framework
- canonical geocoding
- polished media/gallery system

## External browser libraries
The prototype loads Cytoscape.js, vis-timeline and Leaflet from public CDNs.
An internet connection is therefore required for graph/timeline/map rendering unless those libraries are later vendored locally.

## Datasette
`datasette/` contains a minimal configuration for testing the same SQLite database with Datasette separately.


## Validation status

The packaged smoke test has passed against the real canonical snapshot.
See:
- `SMOKE_TEST_RESULT.json`
- `docs/A6_VALIDATION_RESULT.md`

Automated browser visual verification could not run because the execution environment blocks Chromium access to localhost.
The package therefore needs one normal-browser hands-on pass before A6 is formally closed.
