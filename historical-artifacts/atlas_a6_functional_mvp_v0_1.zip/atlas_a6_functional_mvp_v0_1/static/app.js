const $ = s => document.querySelector(s);
let currentEntity = null;
let currentDetail = null;
let compareIds = [];
let graphInstance = null;
let timelineInstance = null;
let mapInstance = null;

const typeLabel = t => ({
  vehicle:"Veículo", vehicle_instance:"Veículo físico", organization:"Organização", brand:"Marca",
  person:"Pessoa", technology:"Tecnologia", component:"Componente", facility:"Instalação",
  place:"Lugar", competition:"Competição", season:"Temporada", team:"Equipe",
  circuit:"Circuito", circuit_layout:"Layout", regulation:"Regulamento", event:"Evento", entry:"Entry"
}[t] || t);

async function api(path){ const r=await fetch(path); if(!r.ok) throw new Error(await r.text()); return r.json(); }
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));

function statementControl(id,count,status){
  const cls=status==="disputed"?"status-disputed":"";
  return `<button class="source-btn ${cls}" onclick="showEvidence('${id}')">${count||0} fonte${count===1?"":"s"}</button>`;
}

function renderMetadata(entity, externalIds, names){
  const meta=entity.metadata||{};
  const rows=[
    ["ID",entity.id],
    ["Tipo",typeLabel(entity.entity_type)],
    ...Object.entries(meta).filter(([k,v])=>v!==null && v!=="" && !Array.isArray(v) && typeof v!=="object").slice(0,8)
      .map(([k,v])=>[k.replaceAll("_"," "),v]),
  ];
  if(names?.length) rows.push(["Nomes", names.map(n=>n.value).join(" · ")]);
  if(externalIds?.length) rows.push(["IDs externos", externalIds.map(x=>`${x.scheme}: ${x.value}`).join(" · ")]);
  $("#metadata-card").innerHTML=`<div class="metadata-grid">${rows.map(([k,v])=>
    `<div class="meta-item"><small>${esc(k)}</small><div>${esc(v)}</div></div>`).join("")}</div>`;
}

function relationHtml(r, incoming=false){
  const name=incoming?r.subject_name:r.object_name;
  const id=incoming?r.subject_id:r.object_id;
  const arrow=incoming?"←":"→";
  return `<div class="relation">
    <div class="pred">${arrow} ${esc(r.predicate)}</div>
    <button class="entity-link" onclick="loadEntity('${id}')">${esc(name)}</button>
    ${statementControl(r.statement_id,r.claim_count,r.resolution_status)}
  </div>`;
}

function factHtml(f){
  return `<div class="fact">
    <div class="pred">${esc(f.predicate)}</div>
    <div>${esc(f.value)}${f.valid_from||f.valid_until?` <small class="muted">(${esc(f.valid_from||"…")} → ${esc(f.valid_until||"…")})</small>`:""}</div>
    ${statementControl(f.statement_id,f.claim_count,f.resolution_status)}
  </div>`;
}

async function loadEntity(id){
  const d=await api(`/api/entities/${id}`);
  currentEntity=id; currentDetail=d;
  history.replaceState({entity:id},"",`#${id}`);
  $("#empty-state").classList.add("hidden");
  $("#compare-view").classList.add("hidden");
  $("#entity-view").classList.remove("hidden");
  $("#entity-type").textContent=typeLabel(d.entity.entity_type);
  $("#entity-name").textContent=d.entity.canonical_name;
  $("#entity-description").textContent=d.entity.description||"";
  renderMetadata(d.entity,d.external_ids,d.names);
  const rels=[
    ...d.outgoing.map(r=>relationHtml(r,false)),
    ...d.incoming.map(r=>relationHtml(r,true))
  ];
  $("#relations").innerHTML=rels.length?rels.join(""):`<div class="muted">Sem relações registradas.</div>`;
  $("#relation-count").textContent=`${rels.length} relações`;
  $("#facts").innerHTML=d.facts.length?d.facts.map(factHtml).join(""):`<div class="muted">Sem fatos escalares.</div>`;
  $("#events").innerHTML=d.events.length?d.events.map(e=>`<div class="event">
      <div class="pred">${esc(e.date||"sem data")}</div>
      <button class="entity-link" onclick="loadEntity('${e.id}')">${esc(e.canonical_name)}</button><span></span>
    </div>`).join(""):`<div class="muted">Nenhum Event diretamente ligado.</div>`;
  activateTab("overview");
  refreshPin();
}

async function showEvidence(statementId){
  const d=await api(`/api/statements/${statementId}/evidence`);
  const s=d.statement;
  $("#drawer-content").innerHTML=`
    <div class="eyebrow">Statement + provenance</div>
    <h2>${esc(s.subject_name)}</h2>
    <div class="statement-summary"><b>${esc(s.predicate)}</b> → ${esc(s.object_value)}<br>
    <small>${esc(s.confidence)} · ${esc(s.resolution_status)}</small></div>
    <h3>Claims / evidências</h3>
    ${d.evidence.map(e=>`<div class="evidence-item">
      <strong>${esc(e.title)}</strong>
      <div>${esc(e.publisher||"")}${e.published_at?` · ${esc(e.published_at)}`:""}</div>
      ${e.url?`<a href="${esc(e.url)}" target="_blank" rel="noreferrer">Abrir fonte ↗</a>`:""}
      <small>${esc(e.source_type||"")} · tier ${esc(e.source_tier||"—")} · ${esc(e.stance)} / ${esc(e.support_strength)}</small>
    </div>`).join("")}`;
  $("#drawer").classList.add("open");
}
window.showEvidence=showEvidence; window.loadEntity=loadEntity;

function activateTab(name){
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===name));
  document.querySelectorAll(".tab-panel").forEach(p=>p.classList.add("hidden"));
  $(`#tab-${name}`).classList.remove("hidden");
  if(name==="timeline") renderTimeline();
  if(name==="graph") renderGraph();
  if(name==="map") renderMap();
}

async function renderTimeline(){
  const rows=await api(`/api/timeline?entity_id=${currentEntity}&start_year=1880&end_year=2035`);
  const el=$("#timeline");
  if(!rows.length){el.innerHTML=`<div class="empty-state"><p>Nenhum Event datado diretamente ligado a esta entidade.</p></div>`;return;}
  const items=new vis.DataSet(rows.map((r,i)=>{
    let start=r.date;
    if(/^\d{4}$/.test(start)) start=`${start}-01-01`;
    if(/^\d{4}-\d{2}$/.test(start)) start=`${start}-01`;
    return {id:i,content:esc(r.canonical_name),start,title:`${r.date} · ${r.canonical_name}`};
  }));
  if(timelineInstance) timelineInstance.destroy();
  timelineInstance=new vis.Timeline(el,items,{
    stack:true,zoomMin:1000*60*60*24*180,zoomMax:1000*60*60*24*365*170,
    margin:{item:12,axis:12},orientation:"top"
  });
  timelineInstance.on("select",p=>{
    if(p.items.length){const row=rows[p.items[0]]; if(row) loadEntity(row.id);}
  });
}

async function renderGraph(){
  const d=await api(`/api/graph/${currentEntity}?depth=2&limit=90`);
  const typeShapes={person:"ellipse",event:"diamond",organization:"round-rectangle",brand:"round-rectangle",entry:"hexagon",circuit:"round-diamond"};
  const elements=[
    ...d.nodes.map(n=>({data:{id:n.id,label:n.canonical_name,type:n.entity_type}})),
    ...d.edges.map(e=>({data:{id:e.id,source:e.subject_entity_id,target:e.object_entity_id,label:e.predicate}}))
  ];
  graphInstance=cytoscape({
    container:$("#graph"),elements,
    style:[
      {selector:"node",style:{"background-color":"#29313a","label":"data(label)","color":"#dfe5eb","font-size":"10px","text-wrap":"wrap","text-max-width":"110px","text-valign":"bottom","text-margin-y":"7px","width":"34px","height":"34px"}},
      {selector:`node[id = "${currentEntity}"]`,style:{"background-color":"#d7ff68","color":"#ffffff","width":"48px","height":"48px"}},
      {selector:"node[type = 'event']",style:{"shape":"diamond","background-color":"#42566b"}},
      {selector:"node[type = 'person']",style:{"shape":"ellipse","background-color":"#55513c"}},
      {selector:"node[type = 'entry']",style:{"shape":"hexagon","background-color":"#4f3f58"}},
      {selector:"edge",style:{"width":1,"line-color":"#39424c","target-arrow-color":"#596572","target-arrow-shape":"triangle","curve-style":"bezier","label":"data(label)","font-size":"7px","color":"#74808c","text-background-color":"#0e1115","text-background-opacity":.8,"text-background-padding":"2px"}}
    ],
    layout:{name:"cose",animate:false,fit:true,padding:40,nodeRepulsion:9000,idealEdgeLength:95}
  });
  graphInstance.on("tap","node",evt=>loadEntity(evt.target.id()));
}

async function renderMap(){
  const pts=await api("/api/map");
  if(mapInstance){mapInstance.remove();mapInstance=null;}
  mapInstance=L.map("map",{worldCopyJump:true}).setView([32,20],2);
  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png",{
    maxZoom:19,attribution:'&copy; OpenStreetMap contributors'
  }).addTo(mapInstance);
  pts.forEach(p=>{
    const m=L.marker([p.lat,p.lon]).addTo(mapInstance);
    m.bindPopup(`<b>${esc(p.entity_name)}</b><br><small>${esc(p.precision)} · não-canônico</small>${p.entity_id?`<br><button onclick="loadEntity('${p.entity_id}')">Abrir entidade</button>`:""}`);
  });
  setTimeout(()=>mapInstance.invalidateSize(),50);
}

function pinCurrent(){
  if(!currentEntity)return;
  const e=currentDetail.entity;
  if(compareIds.some(x=>x.id===e.id)) compareIds=compareIds.filter(x=>x.id!==e.id);
  else if(compareIds.length<4) compareIds.push({id:e.id,name:e.canonical_name,type:e.entity_type});
  refreshCompare();refreshPin();
}
function refreshPin(){
  const pinned=compareIds.some(x=>x.id===currentEntity);
  $("#pin-compare").textContent=pinned?"✓ fixado":"+ comparar";
}
function refreshCompare(){
  $("#compare-list").innerHTML=compareIds.length?compareIds.map(x=>`<div class="compare-chip"><span>${esc(x.name)}</span><button onclick="removeCompare('${x.id}')">×</button></div>`).join(""):"Nenhuma entidade fixada.";
  $("#compare-btn").disabled=compareIds.length<2;
}
window.removeCompare=id=>{compareIds=compareIds.filter(x=>x.id!==id);refreshCompare();refreshPin();};

async function showCompare(){
  const data=await api(`/api/compare?ids=${compareIds.map(x=>x.id).join(",")}`);
  $("#entity-view").classList.add("hidden");
  $("#empty-state").classList.add("hidden");
  $("#compare-view").classList.remove("hidden");
  $("#compare-grid").innerHTML=data.map(e=>{
    const metadata=Object.entries(e.metadata||{}).slice(0,8);
    const facts=e.facts.filter(f=>f.value!==null).slice(0,12);
    return `<article class="compare-card">
      <div class="type-pill">${esc(typeLabel(e.type))}</div><h3>${esc(e.name)}</h3>
      ${metadata.map(([k,v])=>`<div class="compare-row"><span>${esc(k)}</span><div>${esc(Array.isArray(v)?v.join(", "):JSON.stringify(v).replace(/^"|"$/g,""))}</div></div>`).join("")}
      ${facts.map(f=>`<div class="compare-row"><span>${esc(f.predicate)}</span><div>${esc(f.value)}</div></div>`).join("")}
    </article>`;
  }).join("");
}

async function init(){
  const [featured,stats]=await Promise.all([api("/api/featured"),api("/api/stats")]);
  $("#featured").innerHTML=featured.map(e=>`<button onclick="loadEntity('${e.id}')">${esc(e.canonical_name)}<br><small>${esc(typeLabel(e.entity_type))}</small></button>`).join("");
  $("#stats").textContent=`${stats.counts.entity} entidades · ${stats.counts.statement} statements · ${stats.counts.source} fontes`;
  if(location.hash.length>1){
    try{await loadEntity(location.hash.slice(1));}catch(e){}
  }
}
let searchTimer=null;
$("#search").addEventListener("input",e=>{
  clearTimeout(searchTimer);
  const q=e.target.value.trim();
  if(q.length<2){$("#search-results").classList.add("hidden");return;}
  searchTimer=setTimeout(async()=>{
    const rows=await api(`/api/search?q=${encodeURIComponent(q)}`);
    $("#search-results").innerHTML=rows.length?rows.map(r=>`<div class="search-item" onclick="loadEntity('${r.id}');document.querySelector('#search-results').classList.add('hidden')"><span>${esc(r.canonical_name)}</span><small>${esc(typeLabel(r.entity_type))}</small></div>`).join(""):`<div class="search-item muted">Sem resultados</div>`;
    $("#search-results").classList.remove("hidden");
  },140);
});
document.addEventListener("click",e=>{if(!e.target.closest(".search-wrap"))$("#search-results").classList.add("hidden");});
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>activateTab(b.dataset.tab)));
$("#pin-compare").addEventListener("click",pinCurrent);
$("#compare-btn").addEventListener("click",showCompare);
$("#compare-back").addEventListener("click",()=>{ $("#compare-view").classList.add("hidden"); if(currentEntity)$("#entity-view").classList.remove("hidden"); else $("#empty-state").classList.remove("hidden");});
$("#drawer-close").addEventListener("click",()=>$("#drawer").classList.remove("open"));
init();
