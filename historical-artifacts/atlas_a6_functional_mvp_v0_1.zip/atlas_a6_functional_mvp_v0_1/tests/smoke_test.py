from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient
from app import app, connect

client = TestClient(app)

def entity_id(name):
    with connect() as db:
        row = db.execute("SELECT id FROM entity WHERE canonical_name=?", (name,)).fetchone()
        assert row, f"missing entity: {name}"
        return row[0]

def run():
    results = {}

    r = client.get("/api/stats")
    assert r.status_code == 200
    results["stats"] = r.json()["counts"]

    r = client.get("/api/search", params={"q":"Porsche 917"})
    assert r.status_code == 200
    assert any(x["canonical_name"]=="Porsche 917" for x in r.json())
    results["search_porsche_917"] = len(r.json())

    p917 = entity_id("Porsche 917")
    r = client.get(f"/api/entities/{p917}")
    assert r.status_code == 200
    detail = r.json()
    assert detail["entity"]["canonical_name"] == "Porsche 917"
    results["porsche_917_detail"] = {
        "outgoing":len(detail["outgoing"]),
        "incoming":len(detail["incoming"]),
        "events":len(detail["events"]),
    }

    r = client.get(f"/api/graph/{p917}", params={"depth":2})
    assert r.status_code == 200
    graph = r.json()
    assert len(graph["nodes"]) >= 10
    results["porsche_917_graph"] = {"nodes":len(graph["nodes"]),"edges":len(graph["edges"])}

    r = client.get("/api/timeline", params={"entity_id":p917})
    assert r.status_code == 200
    assert len(r.json()) >= 2
    results["porsche_917_timeline"] = len(r.json())

    # Evidence: pick a sourced statement from Porsche 917.
    statement_id = detail["outgoing"][0]["statement_id"] if detail["outgoing"] else detail["incoming"][0]["statement_id"]
    r = client.get(f"/api/statements/{statement_id}/evidence")
    assert r.status_code == 200
    assert len(r.json()["evidence"]) >= 1
    results["evidence_drawer"] = len(r.json()["evidence"])

    # The 911 rename conflict must still be visible.
    rename = entity_id("Porsche 901 renamed Porsche 911")
    r = client.get(f"/api/entities/{rename}")
    assert r.status_code == 200
    rename_facts = [x for x in r.json()["facts"] if x["predicate"]=="occurred_on"]
    assert len(rename_facts) == 2
    assert {x["resolution_status"] for x in rename_facts} == {"disputed"}
    results["911_conflict"] = sorted(x["value"] for x in rename_facts)

    # Compare two vehicles.
    model_t = entity_id("Ford Model T")
    benz = entity_id("Benz Patent Motor Car")
    r = client.get("/api/compare", params={"ids":f"{model_t},{benz}"})
    assert r.status_code == 200
    assert len(r.json()) == 2
    results["compare"] = [x["name"] for x in r.json()]

    # Shortest path between historical entities should be computable when connected.
    entry = entity_id("1970 Le Mans #23 — Porsche 917 K 917-023 — Attwood/Herrmann")
    attwood = entity_id("Richard Attwood")
    r = client.get("/api/path", params={"from_id":entry,"to_id":attwood})
    assert r.status_code == 200
    path = r.json()
    assert len(path["nodes"]) >= 2
    results["path_entry_to_attwood"] = [x["canonical_name"] for x in path["nodes"]]

    # Prototype map surface.
    r = client.get("/api/map")
    assert r.status_code == 200
    assert len(r.json()) >= 5
    results["map_points"] = len(r.json())

    # Root HTML.
    r = client.get("/")
    assert r.status_code == 200
    assert "ATLAS" in r.text
    results["html"] = "pass"

    return results

if __name__ == "__main__":
    import json
    print(json.dumps(run(), ensure_ascii=False, indent=2))
