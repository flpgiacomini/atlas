# Smoke test

From the A6 package directory:

```bash
python tests/smoke_test.py
```

It verifies:
- stats/search;
- Entity page API;
- graph;
- timeline;
- Statement provenance;
- Porsche 911 conflicting-date preservation;
- comparison;
- shortest path;
- map surface;
- root HTML.
