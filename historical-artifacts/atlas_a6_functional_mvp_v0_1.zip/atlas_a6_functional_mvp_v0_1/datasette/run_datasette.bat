@echo off
cd /d "%~dp0\.."
datasette data\atlas.sqlite --metadata datasette\metadata.yml --setting sql_time_limit_ms 5000
