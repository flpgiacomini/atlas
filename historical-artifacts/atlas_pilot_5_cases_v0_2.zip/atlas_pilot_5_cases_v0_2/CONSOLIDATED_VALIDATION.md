# ATLAS — Five-case Pilot Validation v0.2

Included pilots:
1. Porsche 917 — race vehicle, variants, chassis, engineering, Events and Motorsport Entry.
2. Porsche 911 — family/generations/variants, historic naming, overlapping periods and conflicting official sources.
3. Gurgel BR-800 — regional manufacturer, component, successor and corporate-end semantics.
4. Ford Model T — facilities, production movement and manufacturing technology.
5. Nürburgring — circuit identity, layout lineage, physical changes and temporal geometry.

## Consolidated model conclusions

### Confirmed
- Entity remains the identity primitive.
- Event and Entry should both be Entity subtypes.
- Statement is the single factual/relationship primitive.
- Claim → Evidence → Source is justified by real historical ambiguity.
- Vehicle Family / Generation / Variant can remain one Vehicle type with level metadata.
- Organization and Brand must remain distinct.
- Circuit and CircuitLayout must remain distinct.
- Facility and Place remain distinct.
- Component and Technology remain distinct.

### New constraints from the pilots
- Do not equate source-defined generation periods with exact production dates.
- Do not collapse company bankruptcy, operations end, brand dormancy and legal dissolution.
- Do not store one global circuit length.
- Physical vehicle instances can change configuration contextually.
- Cross-generation derivative lineages should first use multiple relationships before a new entity type is introduced.
- Official sources can contradict each other; provenance is required even for primary/manufacturer sources.

## Still intentionally unresolved
- Physical database.
- API.
- Frontend framework.
- Search engine.
- Automation/ingestion pipeline.
- Whether a graph database is ever necessary.
