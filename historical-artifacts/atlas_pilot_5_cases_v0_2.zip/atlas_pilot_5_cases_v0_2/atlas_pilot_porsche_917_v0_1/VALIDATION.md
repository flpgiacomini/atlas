# Validation Notes — Porsche 917 Pilot

## Model findings

### 1. Entry becomes Entity
This is the most important change from Data Model v1.1.
If Entry were only a special record, its start number, drivers, chassis, entrant and result would not naturally
participate in Statement → Claim → Evidence. Treating Entry as an Entity solves that without adding a new mechanism.

### 2. VehicleInstance needs `configured_as`
A physical chassis belongs to the broader vehicle family but can represent different variants/configurations over time.
For chassis 917-023, the Le Mans 1970 context is represented as `configured_as -> Porsche 917 K` with an event qualifier.

### 3. Specialized files are storage views, not separate identities
`events.yaml` and `entries.yaml` contain Entity subtypes. Their records must not be duplicated in `entities.yaml`.

### 4. Racing database data is complementary
Racing Sports Cars is useful for chassis/entry/result discovery and cross-checking, but the pilot prioritizes Porsche
and the Le Mans organizer for load-bearing historical statements where available.

## Questions this dataset can already answer

- Who was responsible for the overall engineering of the Porsche 917?
- Which engine component is associated with the 917?
- What variants are grouped under the Porsche 917 family?
- When was chassis 917-001 completed?
- When was the 917 presented in Geneva?
- When was the 917 homologated?
- What was the first race victory represented in the pilot?
- Which chassis/variant won Le Mans in 1970?
- Who drove the winning entry?
- Which team/entrant fielded it?
- What was its start number and finishing position?
- Which 917 derivatives used turbocharging?

## Questions intentionally NOT yet answered

- Complete race history of every 917 chassis.
- Full ownership history of every chassis.
- Every engine displacement/configuration used by every chassis.
- Complete regulatory lineage.
- Every body/aero revision.
- Every team and sponsor.
