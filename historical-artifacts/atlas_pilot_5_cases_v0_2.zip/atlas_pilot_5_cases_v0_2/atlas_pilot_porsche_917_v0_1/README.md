# ATLAS Pilot Dataset — Porsche 917 v0.1

This is the first serialized pilot of the Atlas knowledge model.

## Purpose
Validate the semantic model with real historical data before selecting a database, API or frontend.

## Files
- `entities.yaml` — vehicles, instances, people, organizations, teams, competitions, circuits, technology and components.
- `events.yaml` — Event entities.
- `entries.yaml` — Motorsport Entry entities.
- `statements.yaml` — all factual statements and entity-to-entity relations.
- `claims.yaml` — source positions supporting statements.
- `evidence.yaml` — evidence records tied to sources.
- `sources.yaml` — source registry.
- `predicates.yaml` — controlled predicate vocabulary used in this pilot.
- `manifest.yaml` — counts, validation result and model changes.

## Important modeling result
`Entry` is treated as an Entity subtype. This removes the previous exception where event participation data
(number, drivers, vehicle, chassis, entrant, result) would otherwise sit outside the Statement/Claim/Evidence chain.

## Validation
Structural validation: PASSED

Counts:
{
  "entities_base": 21,
  "events": 5,
  "entries": 2,
  "statements": 43,
  "claims": 75,
  "evidence": 75,
  "sources": 8,
  "predicates": 19
}

## Scope warning
This is deliberately NOT a complete Porsche 917 racing history. It includes enough data to exercise:
- vehicle family and variants;
- physical chassis identity;
- configuration-by-context;
- people and engineering;
- engine/component;
- technology;
- homologation;
- Motorsport Event;
- Motorsport Entry;
- chassis/driver/team/result;
- provenance.

The next pilot should expand the same structure rather than adding new entity types by default.
