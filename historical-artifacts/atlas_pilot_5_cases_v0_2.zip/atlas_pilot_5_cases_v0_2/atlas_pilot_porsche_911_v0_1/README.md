# ATLAS Pilot Dataset — Porsche 911 v0.1

Purpose: validate the Atlas model with a long-lived vehicle family containing generations, variants,
historic designations, overlapping source periods and technology changes.

## Key finding
Two official Porsche historical pages conflict on the 901→911 rename date:
- 22 October 1964
- 22 November 1964

The dataset preserves both statements as disputed instead of selecting one silently.

## Important semantic distinction
The source period used by Porsche to describe a generation (for example 1963–1973) is not the same
thing as an exact production interval. Porsche separately records series production of the 901 starting
on 14 September 1964. The pilot therefore keeps `source_period` as descriptive metadata and models
specific historical events independently.

## Files
- entities.yaml
- events.yaml
- statements.yaml
- claims.yaml
- evidence.yaml
- sources.yaml
- predicates.yaml
- acceptance_tests.yaml
- manifest.yaml
