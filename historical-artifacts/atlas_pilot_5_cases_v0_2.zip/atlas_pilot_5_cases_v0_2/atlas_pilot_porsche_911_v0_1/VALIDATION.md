# Validation Notes — Porsche 911

## PASS
- Family → generation genealogy can be represented with generic Vehicle entities.
- Generation succession does not require separate Generation tables.
- Internal Porsche type codes can be represented as typed names.
- A prototype precursor (Type 754 T7) can connect to the later 911 without a new schema.
- Targa and Turbo can initially be represented as Vehicle variants.
- Technology transitions can be connected to variants/generations and Events.

## MODEL PRESSURE
1. Generation periods are descriptive and can overlap.
2. `production_start` must not be inferred from a generation label such as “1963–1973”.
3. The 901→911 rename has conflicting dates in official Porsche sources.
4. Long-running sub-lineages such as Targa, Turbo, GT3 and Carrera may span many generations.
   We should first test multiple `part_of` parents before inventing `VehicleLineage`.
5. Names need provenance when their timing matters historically.

## DO NOT ADD YET
- VehicleLineage entity type.
- ModelYear entity.
- BodyStyle entity.
- Facelift entity.
- Separate Generation/Variant tables.
