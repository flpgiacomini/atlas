# ATLAS Pilot Dataset — Ford Model T

Pilot dataset for semantic-model validation. It is deliberately selective, not an exhaustive catalogue.

## Model findings
- Facility relationships need validity periods; 'produced_at' is not timeless.
- Manufacturing technology is best connected both to the facility and, when useful, to the vehicle.
- Historical events and temporal relationships complement rather than replace each other.

## Structural validation
PASSED
