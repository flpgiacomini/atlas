# ATLAS Pilot Dataset — Nürburgring v0.2

Corrected pilot. v0.1 contained duplicate Statement IDs that were exposed when importing into SQLite.
This version regenerates IDs and is intended for the canonical five-case merge.
