# ATLAS A9 Product v0.3

Final-phase implementation package.

New in v0.3:
- global path/graph exploration page;
- filterable global timeline;
- build validation script;
- GitHub Actions build gate;
- GitHub Pages fallback workflow;
- static provider-independent deployment contract.

A9 is **not yet Product Complete** because the actual Astro/Pagefind build, release-ready geometry,
visual usability acceptance and hands-on research workspace validation still need to happen in an environment
with Node package installation/browser access.
