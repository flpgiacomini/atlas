# ATLAS Pilot Dataset — Nürburgring

Pilot dataset for semantic-model validation. It is deliberately selective, not an exhaustive catalogue.

## Model findings
- Circuit identity and CircuitLayout identity must remain separate.
- A circuit can have parallel layouts and successor lineages at the same time.
- Length belongs to a layout/configuration, not to the Circuit entity globally.
- Combined layouts used by events should not become a new entity until they require persistent geometry/identity.

## Structural validation
PASSED
