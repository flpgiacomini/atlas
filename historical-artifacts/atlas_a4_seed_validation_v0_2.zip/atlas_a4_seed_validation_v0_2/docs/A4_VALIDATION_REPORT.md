# ATLAS — A4 Seed Diversity Validation v0.2

## Result
**PASS**

13 new P0 cases were inserted into the canonical Atlas v1 SQLite model.

### Model-change result
- New root Entity types required: **0**
- New Predicates required: **0**
- Predicate Registry refinements: **1**
  - `developed_by` now explicitly accepts `Vehicle` as subject.

### Integrity
- Errors: **0**
- Warnings: **0**
- Canonical entities after A4: **160**
- Statements after A4: **220**
- Sources after A4: **50**
- Claims/Evidence after A4: **308 / 308**

## Cases

### A4-01 Benz Patent-Motorwagen
- Pressure: Origins, patent event, pre-modern vehicle taxonomy
- Statements: 5
- Sources: 2
- Result: **PASS**

### A4-02 Toyoda Model AA
- Pressure: Historical organization, founder guidance, production philosophy
- Statements: 5
- Sources: 2
- Result: **PASS**

### A4-03 Hyundai Pony
- Pressure: Foreign designer + national industry emergence
- Statements: 5
- Sources: 2
- Result: **PASS**

### A4-04 Hongqi CA72
- Pressure: State-led manufacturer + brand/organization separation
- Statements: 5
- Sources: 2
- Result: **PASS**

### A4-05 Tata Nano
- Pressure: Presentation vs launch + changing production facilities
- Statements: 9
- Sources: 2
- Result: **PASS**

### A4-06 Honda N360
- Pressure: Kei/regulatory class + meaningful technical variant
- Statements: 7
- Sources: 2
- Result: **PASS**

### A4-07 Toyota Prius
- Pressure: Concept → production + hybrid technology
- Statements: 7
- Sources: 2
- Result: **PASS**

### A4-08 Nissan LEAF
- Pressure: Announcement/unveiling → actual market launch + BEV
- Statements: 6
- Sources: 2
- Result: **PASS**

### A4-09 Audi quattro
- Pressure: Production vehicle crossing into Motorsport + technology
- Statements: 6
- Sources: 2
- Result: **PASS**

### A4-10 Skoda 1000 MB
- Pressure: Historical geography + factory + production technology
- Statements: 6
- Sources: 2
- Result: **PASS**

### A4-11 Holden 48-215
- Pressure: Prototype programme + physical prototype instance → production vehicle
- Statements: 7
- Sources: 2
- Result: **PASS**

### A4-12 Bugatti revival
- Pressure: Brand continuity across corporate revivals and facilities
- Statements: 13
- Sources: 2
- Result: **PASS**

### A4-13 Toyota 86 Subaru BRZ
- Pressure: Joint development + shared base without identity collapse
- Statements: 8
- Sources: 2
- Result: **PASS**

## Main findings

### 1. National/regulatory classes do not need root Entity types
Honda N360 keeps kei/mini-car classification as contextual metadata in A4.
A Regulation link can be deepened later if a concrete historical regulation becomes important.

### 2. Joint development does not merge product identity
Toyota 86 and Subaru BRZ remain two Vehicle entities.
Both can point to Toyota and Subaru through the existing `developed_by` predicate and share a base through `shares_platform_with`.

### 3. Brand continuity survives organization change
Bugatti remains one Brand while revival Events, facilities, Vehicles and corporate control are represented separately.
No `RevivedBrand` entity type is needed.

### 4. Prototype and physical object remain distinct
Holden's prototype programme is a Vehicle; Prototype No. 1 is a VehicleInstance; the production 48-215 can be `derived_from` the prototype programme.

### 5. Concept is still Vehicle, not a new Concept type
Prius Concept is Vehicle(kind=concept); production Prius can be connected through `derived_from`.

### 6. Announcement/presentation/launch remain Events
LEAF and Nano validate the distinction between presentation and actual launch without adding lifecycle tables.

### 7. Historical organization naming needs careful research, not schema expansion
A4 deliberately avoided over-asserting modern legal organization names for historical Audi/ŠKODA contexts when the source did not require it.
This is a curation discipline issue.

## A4 gate conclusion
The P0 diversity test did **not** break Data Model v1.0.

The model is now stable enough to proceed to **A5 — Chapter I: 1885–1918**.

P1 cases remain optional regression tests, not a blocker.
