# ATLAS — A4 Seed Dataset v0.1

## Purpose
A4 is not a content-production sprint.

It is the final **semantic diversity stress test** before Chapter I begins at scale.

The five original pilots tested difficult structures, but were still concentrated around Porsche, Ford, Gurgel and one German circuit.
A4 deliberately broadens geography, industrial models and technological eras.

## Size
24 seed cases:
- 5 existing anchors
- 13 P0 new cases
- 6 P1 secondary stress cases

The number is deliberately below a broad 50–100 vehicle catalogue.

## P0 new cases
1. Benz Patent-Motorwagen
2. Toyoda Model AA
3. Hyundai Pony
4. Hongqi CA72
5. Tata Nano
6. Honda N360
7. Toyota Prius
8. Nissan LEAF
9. Audi quattro
10. Škoda 1000 MB
11. Holden 48-215
12. Bugatti EB110 → Veyron revival
13. Toyota 86 / Subaru BRZ

These cover:
- origins;
- Asia;
- Oceania;
- state-led industry;
- low-cost industrial strategy;
- kei regulation;
- hybrid;
- BEV;
- Motorsport-derived technology;
- historical-country continuity;
- brand revival;
- joint development/shared base.

## P1 cases
Use only if P0 leaves a semantic question unresolved:
- Hyundai Pony Coupe concept/reconstruction
- Prius concept → production
- Bugatti Veyron preseries chassis
- Tata Nano factory disruption
- Honda N360 AT technical variant
- Audi quattro road ↔ rally bridge

## Research depth per seed
Do not write a complete vehicle history.

Target:
- 1 Entity definition
- 5–12 meaningful Statements
- 1–3 Events
- 2–5 Sources
- enough Evidence to support load-bearing facts
- only components/people/facilities needed by the tested semantic scenario

## Hard stop
When the case has demonstrated the semantic pressure it was selected for, stop.

Example:
Honda N360 is here to test kei classification, technical variants and production context.
A4 does not require documenting every N360 trim or model year.

## A4 success
Data Model v1.0 passes A4 when:
1. no new root Entity type is required;
2. fewer than 5 new Predicates are required;
3. no case requires bypassing Statement → Claim → Evidence;
4. temporal ambiguity remains representable;
5. geography remains external-ID/Place based;
6. shared development does not force entity identity collapse;
7. brand revival remains representable with Brand + Organizations + temporal Statements;
8. concept/reconstruction can be modeled without confusing physical instances;
9. all P0 cases merge into one canonical snapshot without identity collisions.

## A4 failure
A model revision is justified only if a real case cannot be cleanly represented using:
Entity + Statement + qualifier + Event + Entry.

Do not revise the model for cosmetic convenience.
