# A4 Acceptance Gates

## G1 — Geographic diversity
At minimum:
- Europe
- North America
- South America
- East Asia
- South Asia
- Oceania

Africa/Middle East do not need forced token representation in A4 if no case adds a distinct semantic problem.
They remain mandatory for later global content coverage.

## G2 — Industrial diversity
Must include:
- independent manufacturer
- large group
- state-led/national manufacturer
- revived brand
- joint-development case
- extinct manufacturer

## G3 — Vehicle diversity
Must include:
- pioneer vehicle
- mass-market car
- race-related vehicle
- kei/small regulated class
- concept
- hybrid
- BEV
- low-cost car
- preseries/individual chassis

## G4 — Temporal diversity
Cases span:
1880s → current era.

## G5 — Model stability
Allowed during A4:
- clarify metadata;
- add qualifiers;
- add up to 4–5 justified Predicates.

Not allowed without reopening Scope Freeze:
- casual creation of new root Entity types;
- parallel Timeline/Map/Genealogy tables;
- adopting a graph database merely because the dataset grows.

## G6 — Research effort
A4 is complete when the model is tested.
It is not necessary to exhaust every source for every seed.

## Exit
After A4 passes:
**Data Model v1.0 is considered stable enough for historical production research.**
Proceed to A5 — Chapter I: 1885–1918.
