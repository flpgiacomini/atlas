# ATLAS A4 Seed Dataset v0.1

This package defines the final diversity stress-test before Chapter I.

It contains:
- A4 seed matrix
- starter official/institutional sources
- A4 plan
- acceptance gates
- post-A9 lifecycle clarification
- roadmap interpretation
