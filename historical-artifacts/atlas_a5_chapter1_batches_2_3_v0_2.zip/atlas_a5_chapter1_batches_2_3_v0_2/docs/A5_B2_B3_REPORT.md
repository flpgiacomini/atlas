# ATLAS — A5 Batches B2 + B3 Report

## Result
**PASS**

### Added in this round
- Entities: 23
- Statements: 27
- Sources: 13
- Claims/Evidence: 32 / 32
- New root Entity types: 0
- New Predicates: 0

### Canonical totals
{
  "entity": 224,
  "statement": 293,
  "source": 79,
  "claim": 389,
  "evidence": 389,
  "predicate": 54
}

## B2 — France

### Renault Type A
The model now connects:
Louis Renault → Renault Type A → direct-drive dog-clutch technology → rue Lepic demonstration.

### Panhard & Levassor
The chapter now represents:
- Panhard & Levassor as an Organization;
- Panhard-Levassor Type M2E as a Vehicle;
- a Technology Licensing Event connecting Daimler and Panhard & Levassor.

No `licensed_from` Predicate was added because the Event + participant roles already represent the historically relevant fact.

### De Dion-Bouton
The 1895 single-cylinder petroleum engine is represented as a Component with De Dion and Bouton as developers,
connected to De Dion-Bouton through an Event.

This is useful because De Dion-Bouton's historical importance is partly a component/supplier-network story,
not merely a list of its own cars.

## B3 — Germany

### Benz Velo
Benz Velo is now linked to Benz & Cie. and an April 1894 production/sales Event.
The documented 1,200-unit total through 1901 is retained as vehicle metadata rather than creating a one-off production-count Predicate.

### Mercedes 35 hp
The graph now contains:
Wilhelm Maybach → Mercedes 35 hp → first delivery to Emil Jellinek → Nice Race Week 1901 → Wilhelm Werner.

This begins to connect product architecture and Motorsport without yet building the full B6 competition dataset.

### Daimler truck
The 1896 4 hp truck is represented as a commercial Vehicle and linked to Daimler-Motoren-Gesellschaft,
the 1 October 1896 London delivery Event and the British Motor Syndicate recipient.

## Model result
No schema revision was required.

The most important curatorial conclusion is that historically important licensing, demonstrations and deliveries
are often better represented as Events with participant-role qualifiers than as a growing list of bespoke Predicates.
